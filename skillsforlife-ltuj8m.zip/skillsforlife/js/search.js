// Open the full screen search box 
function openSearch() {
  document.getElementById("SearchOverlay").style.display = "block";
document.getElementById("SearchOverlay").style.height = "";


}

// Close the full screen search box 
function closeSearch() {
  document.getElementById("SearchOverlay").style.display = "none";
document.getElementById("SearchOverlay").style.height = "0px";
}